package com.project1.project1;
import Models.UserModel;
import com.project1.project1.controller.ValidationRules;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class Login implements Initializable {
    @FXML
    private Button BtnCancel;

    @FXML
    private Button BtnLogin;

    @FXML
    private Label LblErrormassage;

    @FXML
    private Label LblErrorpassword;

    @FXML
    private Label LblErrorusername;

    @FXML
    private AnchorPane TxtUser;

    @FXML
    private TextField Txtpw;

    @FXML
    private TextField txtuname;

    @FXML
    void btnlog(ActionEvent event) throws IOException {
        String username=txtuname.getText();
        String password=Txtpw.getText();
        LblErrormassage.setText("");
        if (ValidationRules.isEmpty(username)||ValidationRules.isEmpty(password)){
            LblErrormassage.setText("Please enter Username and Password");

        }else {
            UserModel userModel=new UserModel();
            boolean result=userModel.login(username,password);
            if (result){
                System.out.println("Login Success");
                txtuname.clear();
                Txtpw.clear();
                FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("DashBoard.fxml"));
                Scene scene = new Scene(fxmlLoader.load());
                Stage Dashboard=new Stage();
                Dashboard.setTitle("Dashboard");
                Dashboard.setScene(scene);
                Dashboard.show();
                closeLoginWindow();
            }
            else {
                LblErrormassage.setText("Incorrect User name or Password");
            }

    }


}

    private void closeLoginWindow() {
        Stage stage = (Stage) BtnLogin.getScene().getWindow();
        stage.close();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
