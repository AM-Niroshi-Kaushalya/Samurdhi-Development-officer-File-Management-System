package com.project1.project1;
import Models.BenificiaryModel;
import Models.UpdateModel;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.ResourceBundle;

public class UpdateController implements Initializable {
    @FXML
    private TableColumn<Detail, String> Address;

    @FXML
    private TableColumn<Detail, String> Birthday;

    @FXML
    private Button BtnUpdate;

    @FXML
    private AnchorPane ComboGnZone;

    @FXML
    private TableColumn<Detail, String> Ds_Zone;

    @FXML
    private TableColumn<Detail, String> GN_Zone;

    @FXML
    private TextField Gender;

    @FXML
    private TextField Job;

    @FXML
    private TableColumn<Detail, String> NIC;

    @FXML
    private TableColumn<Detail, String> Name_Denoted;

    @FXML
    private TableColumn<Detail, String> Name_Initial;

    @FXML
    private TableColumn<Detail, String> Name_Ssociety;

    @FXML
    private TextField SamurdhiSociety;

    @FXML
    private TextField TXTAdress;

    @FXML
    private TextField TXTBirth;

    @FXML
    private TextField TXTFamilyM;

    @FXML
    private TextField TXTIncome;

    @FXML
    private TextField TXTNameI;

    @FXML
    private TextField TXTTeleNu;

    @FXML
    private TextField TXTnic;

    @FXML
    private TableView<Detail> TableDetail;

    @FXML
    private TableColumn<Detail, String> Tel_number;

    @FXML
    private TableColumn<Detail, String> benififiary_Type;

    @FXML
    private TableColumn<Detail, String> colincome;

    @FXML
    private TableColumn<Detail, String> coljob;

    @FXML
    private TextField division;

    @FXML
    private TableColumn<Detail, String> family_Member;

    @FXML
    private TableColumn<Detail, String> gender;

    @FXML
    private TextField txtbirthday;

    @FXML
    private TextField typeofbeni;

    @FXML
    private TextField zone;

//    @FXML
//    void ClickUpdate(ActionEvent event) {
//
//    }

    @FXML
    void TXTNameD(ActionEvent event) {

    }

    @FXML
    void rowclicked(MouseEvent event) {
        Detail clickedView = TableDetail.getSelectionModel().getSelectedItem();
        TXTNameI.setText(String.valueOf(clickedView.getName_Initial()));
        TXTBirth.setText(String.valueOf(clickedView.getName_Denoted()));
        txtbirthday.setText(String.valueOf(clickedView.getBirthday()));
        TXTnic.setText(String.valueOf(clickedView.getNIC()));
        Gender.setText(String.valueOf(clickedView.getGender()));
        TXTFamilyM.setText(String.valueOf(clickedView.getFamily_Members()));
        TXTAdress.setText(String.valueOf(clickedView.getAddress()));
        Job.setText(String.valueOf(clickedView.getJob()));
        TXTTeleNu.setText(String.valueOf(clickedView.getTele_Number()));
        TXTIncome.setText(String.valueOf(clickedView.getIncome()));
        division.setText(String.valueOf(clickedView.getDs_Zone()));
        zone.setText(String.valueOf(clickedView.getGN_Zone()));
        SamurdhiSociety.setText(String.valueOf(clickedView.getName_Ssociety()));
        typeofbeni.setText(String.valueOf(clickedView.getBenificiary_Type()));

    }





    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        UpdateModel updateModel = new UpdateModel();
        Name_Initial.setCellValueFactory(new PropertyValueFactory<Detail, String>("Name_Initial"));
        Name_Denoted.setCellValueFactory(new PropertyValueFactory<Detail, String>("Name_Denoted"));
        Birthday.setCellValueFactory(new PropertyValueFactory<Detail, String>("Birthday"));
        NIC.setCellValueFactory(new PropertyValueFactory<Detail, String>("NIC"));
        gender.setCellValueFactory(new PropertyValueFactory<Detail, String>("Gender"));
        family_Member.setCellValueFactory(new PropertyValueFactory<Detail, String>("Family_Members"));
        Address.setCellValueFactory(new PropertyValueFactory<Detail, String>("Address"));
        coljob.setCellValueFactory(new PropertyValueFactory<Detail, String>("Job"));
        Tel_number.setCellValueFactory(new PropertyValueFactory<Detail, String>("Tele_Number"));
        colincome.setCellValueFactory(new PropertyValueFactory<Detail, String>("Income"));
        Ds_Zone.setCellValueFactory(new PropertyValueFactory<Detail, String>("Ds_Zone"));
        GN_Zone.setCellValueFactory(new PropertyValueFactory<Detail, String>("GN_Zone"));
        Name_Ssociety.setCellValueFactory(new PropertyValueFactory<Detail, String>("Name_Ssociety"));
        benififiary_Type.setCellValueFactory(new PropertyValueFactory<Detail, String>("Benificiary_Type"));
        TableDetail.setItems(updateModel.getUpdate());

    }

    @FXML
    void ClickUpdate(ActionEvent event) {
        ObservableList<Detail> currentTabledata = TableDetail.getItems();
        String currentnic = (TXTnic.getText());
        for (Detail detail : currentTabledata) {
            detail.setName_Initial(TXTNameI.getText());
            detail.setName_Denoted(TXTBirth.getText());
            detail.setBirthday(txtbirthday.getText());
            detail.setNIC(TXTnic.getText());
            detail.setGender(Gender.getText());
            detail.setFamily_Members(TXTFamilyM.getText());
            detail.setAddress(TXTAdress.getText());
            detail.setJob(Job.getText());
            detail.setTele_Number(TXTTeleNu.getText());
            detail.setIncome(TXTIncome.getText());
            detail.setDs_Zone(division.getText());
            detail.setGN_Zone(zone.getText());
            detail.setName_Ssociety(SamurdhiSociety.getText());
            detail.setBenificiary_Type(typeofbeni.getText());
            TableDetail.setItems(currentTabledata);
            TableDetail.refresh();

            String namei = TXTNameI.getText();
            String named = TXTBirth.getText();
            String birth = txtbirthday.getText();
            String nic = TXTnic.getText();
            String gender = Gender.getText();
            String fm = TXTFamilyM.getText();
            String address = TXTAdress.getText();
            String job = Job.getText();
            String tele = TXTTeleNu.getText();
            String income = TXTIncome.getText();
            String div = division.getText();
            String zones = zone.getText();
            String society = SamurdhiSociety.getText();
            String btype = typeofbeni.getText();
            UpdateModel updateModel = new UpdateModel();
            boolean result = updateModel.Updateuser(namei, named, birth, nic, gender, fm, address, job, tele, income, div, zones, society, btype);
            break;
        }


    }
}




















