package com.project1.project1.controller;

import Models.UserTypesModel;

//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.HashMap;

public class Helper {
//    public static <BiMap> String selectedUserStatus(String val, Boolean isInverse){
//        BiMap<String,String>status= HashBinMap.create();
//        UserTypesModel userTypesModel=new UserTypesModel();
//        ResultSet rs =userTypesModel.getTypes();
//        try {
//            while (rs.next()) {
//                status.put(rs.getString("ut_id"), rs.getString("ut_name"));
//            }
//        }catch (SQLException e){
//            throw new RuntimeException(e);
//        }
//          if (isInverse)  {
//              return status.inverse().get(val);
//          }else {
//              return status.get(val);
//
//
//          }
//

            
        
    }


