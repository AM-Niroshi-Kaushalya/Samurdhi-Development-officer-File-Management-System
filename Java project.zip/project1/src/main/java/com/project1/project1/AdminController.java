package com.project1.project1;
import Models.UserModel;
import at.favre.lib.crypto.bcrypt.BCrypt;
import com.project1.project1.controller.ValidationRules;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.ArrayList;


public class AdminController {
    @FXML
    private Button btnreg;

    @FXML
    private Label errormessage;

    @FXML
    private TextField txtpw;

    @FXML
    private TextField txtuname;

    @FXML
    private Label LableSuccess;


    @FXML
    void btnloggin(ActionEvent event) {
        errormessage.setText("");
        txtuname.getStyleClass().remove("errors");
        txtpw.getStyleClass().remove("errors");
        String username=txtuname.getText();
        String password=txtpw.getText();
        UserModel userModel = new UserModel();
        String hashpass= BCrypt.withDefaults().hashToString(12,password.toCharArray());
        ArrayList<Integer> errors = new ArrayList<>();
        if(ValidationRules.isEmpty(username)||ValidationRules.isEmpty(password)){
            errors.add(1);
            errormessage.setText("All fields are required");
        }
        else {
            if (!ValidationRules.isText(username)){
                errors.add(1);
                errormessage.setText("Invalid user name");
                txtuname.getStyleClass().add("errors");
            }
            if (!ValidationRules.minLen(password,5)){
                errors.add(1);
                errormessage.setText("Password must have at least five charactors");
                txtpw.getStyleClass().add("errors");
            }
            else {
                boolean result= userModel.btnloggin(username,hashpass);
                if (result){
                    LableSuccess.setText("User added");
                }
            }
        }




    }
}






