package com.project1.project1;

import javafx.scene.control.CheckBox;

public class Student {
    public String id,name;

    public CheckBox SelectStudent;

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }
    public CheckBox getSelectStudent() {
        return SelectStudent;
    }
    public void setSelectStudent(CheckBox SelectStudent){this.SelectStudent=SelectStudent;}


    @Override
    public String toString() {
        return "Student{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", SelectStudent=" + SelectStudent +
                '}';
    }

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
        this.SelectStudent=new CheckBox();
    }
}
