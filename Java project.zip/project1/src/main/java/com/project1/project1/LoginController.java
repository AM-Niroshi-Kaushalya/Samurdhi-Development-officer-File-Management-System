package com.project1.project1;
import Models.Db;
import Models.UserTypesModel;
import Models.ZoneModel;
import com.project1.project1.controller.ValidationRules;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.ResourceBundle;

//import static com.sun.javafx.css.StyleManager.errors;


public class LoginController implements Initializable {
    @FXML
    private Button BtnReg;

    @FXML
    private ComboBox ComboL;

    @FXML
    private Label LBLError;

    @FXML
    private Label LBLErrorEmail;

    @FXML
    private Label LBLErrorLname;

    @FXML
    private Label LBLErrorMnum;

    @FXML
    private Label LBLErrorPassword;

    @FXML
    private Label LBLerrorFname;

    @FXML
    private Label LBLsuccess;

    @FXML
    private TextField TxtE;

    @FXML
    private TextField TxtLname;

    @FXML
    private TextField Txtmn;

    @FXML
    private TextField Txtname;

    @FXML
    private TextField Txtpassword;

    @FXML
    private Button cancelButton;
    @FXML
    private ComboBox zone;

    @FXML
    void BtnReg(ActionEvent event, Object e) {

    }
    @FXML
    void onCancelButtonClick( ) {
        Stage stage=(Stage) cancelButton.getScene().getWindow();
        stage.close();

    }


    public void BtnReg(ActionEvent ex) {
      LBLError.setText("");
      LBLsuccess.setText("");
      LBLerrorFname.setText("");
      LBLErrorLname.setText("");
      LBLErrorMnum.setText("");
      LBLErrorEmail.setText("");
      LBLErrorPassword.setText("");


      Txtname.getStyleClass().remove("errors");
      TxtLname.getStyleClass().remove("errors");
      Txtmn.getStyleClass().remove("errors");
      TxtE.getStyleClass().remove("errors");
      Txtpassword.getStyleClass().remove("errors");





      String fname = Txtname.getText();
      String lname = TxtLname.getText();
      String mnomber = Txtmn.getText();
      String eml = TxtE.getText();
      String psword = Txtpassword.getText();
      String st=(String) ComboL.getSelectionModel().getSelectedItem();
      String st1=(String) zone.getSelectionModel().getSelectedItem();

     System.out.println(st);
        ArrayList<Integer> errors = new ArrayList<Integer>();
     //String st=(String) ComboL.getSelectionModel().getSelectedItem();

        if (ValidationRules.isEmpty(fname) || ValidationRules.isEmpty(lname) ||
                ValidationRules.isEmpty(mnomber) || ValidationRules.isEmpty(eml) ||
                ValidationRules.isEmpty(psword)
        ){
            errors.add(1);
            LBLError.setText("All fields are required");
        }else
            {
                if (!ValidationRules.isText(fname)) {
                    errors.add(1);
                    LBLerrorFname.setText("Invalid first name");
                    Txtname.getStyleClass().add("errors");
                }
                if (!ValidationRules.isText(lname)) {
                    errors.add(1);
                    LBLErrorLname.setText("Invalid last name");
                    TxtLname.getStyleClass().add("errors");
                }
                if (!ValidationRules.isMobile(mnomber)) {
                    errors.add(1);
                    LBLErrorMnum.setText("Invalid mobile number");
                    Txtmn.getStyleClass().add("errors");
                }
                if (!ValidationRules.isEmail(eml)) {
                    errors.add(1);
                    LBLErrorEmail.setText("Invalid email address");
                    TxtE.getStyleClass().add("errors");
                }
                if (!ValidationRules.minLen(psword, 5)) {
                    errors.add(1);
                   LBLErrorPassword.setText("Password must have at least 5 characters");
                   Txtpassword.getStyleClass().add("errors");
              }



         Connection conn = Db.getConn();

        String sql= "INSERT INTO `user25`(`First_Name`, `Last_Name`, `Mobile_No`, `Email`, `Password` ,`ComboL` ,`zone`) VALUES (?,?,?,?,?,?,?)";
         try{
            PreparedStatement stat;
             stat = conn.prepareStatement(sql);
             stat.setString(1,fname);
             stat.setString(2,lname );
             stat.setString(3,mnomber );
             stat.setString(4,eml );
             stat.setString(5,psword );
             stat.setString(6,st );
             stat.setString(7,st1 );

             boolean result = stat.executeUpdate()==1;
             if(result){
              System.out.println("Insert Success");
            }
              Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/sample23","root","");
           }catch (SQLException exx){
             System.out.println(exx.getMessage());          }
     }}


   @Override
   public void initialize(URL url, ResourceBundle resourceBundle){
//        UserTypesModel userTypesModel = new UserTypesModel();
//          ResultSet rs = userTypesModel.getTypes();
//          try {
//              while (rs.next()) {
//                 System.out.println(rs.getString("ut_name"));
//
//                  ComboL.getItems().add(rs.getString("ut_name"));
//              }
//          } catch (SQLException ex) {
//               System.out.println(ex.getMessage());
//           }
//

       //throw new RuntimeException(ex);

    ZoneModel zoneModel= new ZoneModel();
    ResultSet rsk = zoneModel.getTypes();
          try {
         while (rsk.next()) {
            System.out.println(rsk.getString("id"));

            zone.getItems().add(rsk.getString("zone"));
        }
     }  catch (SQLException ex) {
        System.out.println(ex.getMessage());
    }




   }



}










