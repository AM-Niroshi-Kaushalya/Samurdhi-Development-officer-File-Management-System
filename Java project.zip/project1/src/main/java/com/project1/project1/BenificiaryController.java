package com.project1.project1;
import Models.BeniTypeModel;
import Models.DetailModel;
import Models.GNZoneModel;
import Models.SocietyModel;
import com.project1.project1.controller.ValidationRules;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;


public class BenificiaryController implements Initializable {
  @FXML
  private Button BtnCancel;

  @FXML
  private Button BtnSubmit;

  @FXML
  private ComboBox<String> ComboBenifit;

  @FXML
  private ComboBox<String> ComboGnZone;

  @FXML
  private ComboBox<String> Combosociety;

  @FXML
  private Label LblErreoTele;

  @FXML
  private Label LblErrorAdress;

  @FXML
  private Label LblErrorBenificiary;

  @FXML
  private Label LblErrorDate;

  @FXML
  private Label LblErrorDenotedI;

  @FXML
  private Label LblErrorDs;

  @FXML
  private Label LblErrorEmpty;

  @FXML
  private Label LblErrorFamily;

  @FXML
  private Label LblErrorGender;

  @FXML
  private Label LblErrorGnz;

  @FXML
  private Label LblErrorIncome;

  @FXML
  private Label LblErrorInitial;

  @FXML
  private Label LblErrorJob;

  @FXML
  private Label LblErrorNIC;

  @FXML
  private Label LblErrorSs;

  @FXML
  private AnchorPane LblSuccess;

  @FXML
  private TextField TXTAdress;

  @FXML
  private TextField TXTBirth;

  @FXML
  private TextField TXTDevitionalZ;

  @FXML
  private TextField TXTFamilyM;

  @FXML
  private TextField TXTGender;

  @FXML
  private TextField TXTIncome;

  @FXML
  private TextField TXTJob;

  @FXML
  private TextField TXTNameD;

  @FXML
  private TextField TXTNameI;

  @FXML
  private TextField TXTTeleNu;

  @FXML
  private TextField TXTnic;

  @FXML
  private Label lblSuc;


  @FXML
  void Cancel(ActionEvent event) {

  }

  @FXML
  void Detail(ActionEvent event) {
    LblErrorEmpty.setText("");
    //LblSuccess.setText("");
    LblErrorInitial.setText("");
    LblErrorDenotedI.setText("");
    LblErrorDate.setText("");
    LblErrorNIC.setText("");
    LblErrorGender.setText("");
    LblErrorFamily.setText("");
    LblErrorAdress.setText("");
    LblErrorJob.setText("");
    LblErreoTele.setText("");
    LblErrorIncome.setText("");
    LblErrorDs.setText("");
    LblErrorGnz.setText("");
    LblErrorSs.setText("");
    LblErrorBenificiary.setText("");
    lblSuc.setText("");

    TXTNameI.getStyleClass().remove("errors");
    TXTNameD.getStyleClass().remove("errors");
    TXTBirth.getStyleClass().remove("errors");
    TXTnic.getStyleClass().remove("errors");
    TXTGender.getStyleClass().remove("errors");
    TXTFamilyM.getStyleClass().remove("errors");
    TXTAdress.getStyleClass().remove("errors");
    TXTJob.getStyleClass().remove("errors");
    TXTTeleNu.getStyleClass().remove("errors");
    TXTIncome.getStyleClass().remove("errors");
    TXTDevitionalZ.getStyleClass().remove("errors");

    String Iname = TXTNameI.getText();
    String Dname = TXTNameD.getText();
    String DBirth = TXTBirth.getText();
    String Nic = TXTnic.getText();
    String Gender = TXTGender.getText();
    String Family = TXTFamilyM.getText();
    String Address = TXTAdress.getText();
    String Job = TXTJob.getText();
    String Telenu = TXTTeleNu.getText();
    String Mincome = TXTIncome.getText();
    String DevitionalZ = TXTDevitionalZ.getText();
    String st2 = (String) ComboGnZone.getSelectionModel().getSelectedItem();
    String st3 = (String) Combosociety.getSelectionModel().getSelectedItem();
    String st4 = (String) ComboBenifit.getSelectionModel().getSelectedItem();
    ArrayList<Integer> errors = new ArrayList<Integer>();
    if (ValidationRules.isEmpty(Iname) ||  ValidationRules.isEmpty(Dname) ||
            ValidationRules.isEmpty(DBirth) || ValidationRules.isEmpty(Nic) ||
            ValidationRules.isEmpty(Gender) || ValidationRules.isEmpty(Family)||
            ValidationRules.isEmpty(Address) || ValidationRules.isEmpty(Job)||
            ValidationRules.isEmpty(Telenu) || ValidationRules.isEmpty(Mincome) ||
            ValidationRules.isEmpty(DevitionalZ) || ValidationRules.isEmpty(st2)||
            ValidationRules.isEmpty(st3)|| ValidationRules.isEmpty(st4)

    ){
      errors.add(1);
      LblErrorEmpty.setText("All fields are required");
    }else {
      if (!ValidationRules.isText(Iname)) {
        errors.add(1);
        LblErrorInitial.setText("Invalid first name");
        TXTNameI.getStyleClass().add("errors");
      }
      if (!ValidationRules.isText(Dname)) {
        errors.add(1);
        LblErrorDenotedI.setText("Invalid last name");
        TXTNameD.getStyleClass().add("errors");
      }
      if (!ValidationRules.isMobile(Telenu)) {
        errors.add(1);
        LblErreoTele.setText("Invalid mobile number");
        TXTTeleNu.getStyleClass().add("errors");
      }else {
        boolean result = DetailModel.Detail(Iname, Dname, DBirth, Nic, Gender, Family, Address, Job, Telenu, Mincome, DevitionalZ, st2, st3, st4);
        if (result){
          lblSuc.setText("New Benificiary added");
        }}}}


  @Override
  public void initialize(URL url, ResourceBundle resourceBundle) {
    BeniTypeModel beniTypeModel = new BeniTypeModel();
    ResultSet rsb = beniTypeModel.getTypes();
    try {
      while (rsb.next()) {
        //System.out.println(rsb.getString("id"));


        ComboBenifit.getItems().add(rsb.getString("Type"));
      }
    } catch (SQLException ex) {
      //System.out.println(ex.getMessage());
      throw new RuntimeException(ex);
    }

    SocietyModel societyModel = new SocietyModel();
    ResultSet rss = societyModel.getTypes();
    try {
      while (rss.next()) {
        //System.out.println(rss.getString("So_id"));

        Combosociety.getItems().add(rss.getString("So_name"));
      }
    } catch (SQLException ex) {
      System.out.println(ex.getMessage());
    }

    GNZoneModel gnZoneModel = new GNZoneModel();
    ResultSet rsg = gnZoneModel.getTypes();
    try {
      while (rsg.next()) {
        System.out.println(rsg.getString("GN_id"));

        ComboGnZone.getItems().add(rsg.getString("GN_name"));
      }
    } catch (SQLException ex) {
      //System.out.println(ex.getMessage());
      throw new RuntimeException(ex);
    }

  }

  public void OnclickBeni(ActionEvent actionEvent) {
  }

  public void OnclickApp(ActionEvent actionEvent) {
  }
  }








