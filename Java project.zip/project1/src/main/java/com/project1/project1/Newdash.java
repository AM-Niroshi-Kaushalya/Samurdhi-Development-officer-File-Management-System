package com.project1.project1;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;

public class Newdash {
    @FXML
    private AnchorPane Paneview;

    @FXML
    private Button btnapp;

    @FXML
    private Button btnben;

    @FXML
    private Button btndashboard;

    @FXML
    private Button btnupdate;

    @FXML
    private Button btnAdminreg;

    @FXML
    void Btnadmin(ActionEvent event) throws IOException {
        AnchorPane pane = new FXMLLoader().load(App.class.getResource("Admin.fxml"));
        Paneview.getChildren().setAll(pane);

    }

    @FXML
    void Btnbeni(ActionEvent event) throws IOException {
        AnchorPane pane = new FXMLLoader().load(App.class.getResource("Detail.fxml"));
        Paneview.getChildren().setAll(pane);

    }

    @FXML
    void Btnupdate(ActionEvent event) throws IOException {
        AnchorPane pane = new FXMLLoader().load(App.class.getResource("Updateview.fxml"));
        Paneview.getChildren().setAll(pane);

    }

    @FXML
    void application(ActionEvent event) throws IOException {
        AnchorPane pane = new FXMLLoader().load(App.class.getResource("Benificiary.fxml"));
        Paneview.getChildren().setAll(pane);

    }

}
