package com.project1.project1;

public class Detail {
    public String Name_Initial, Name_Denoted, Birthday, NIC, Gender, Family_Members, Address,Job, Tele_Number, Income, Ds_Zone, GN_Zone, Name_Ssociety, Benificiary_Type;

    public String getName_Initial() {
        return Name_Initial;
    }

    public void setName_Initial(String name_Initial) {
        Name_Initial = name_Initial;
    }

    public String getName_Denoted() {
        return Name_Denoted;
    }

    public void setName_Denoted(String name_Denoted) {
        Name_Denoted = name_Denoted;
    }

    public String getBirthday() {
        return Birthday;
    }

    public void setBirthday(String birthday) {
        Birthday = birthday;
    }

    public String getNIC() {
        return NIC;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getFamily_Members() {
        return Family_Members;
    }

    public void setFamily_Members(String family_Members) {
        Family_Members = family_Members;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getJob() {
        return Job;
    }

    public void setJob(String job) {
        Job = job;
    }

    public String getTele_Number() {
        return Tele_Number;
    }

    public void setTele_Number(String tele_Number) {
        Tele_Number = tele_Number;
    }

    public String getIncome() {
        return Income;
    }

    public void setIncome(String income) {
        Income = income;
    }

    public String getDs_Zone() {
        return Ds_Zone;
    }

    public void setDs_Zone(String ds_Zone) {
        Ds_Zone = ds_Zone;
    }

    public String getGN_Zone() {
        return GN_Zone;
    }

    public void setGN_Zone(String GN_Zone) {
        this.GN_Zone = GN_Zone;
    }

    public String getName_Ssociety() {
        return Name_Ssociety;
    }

    public void setName_Ssociety(String name_Ssociety) {
        Name_Ssociety = name_Ssociety;
    }

    public String getBenificiary_Type() {
        return Benificiary_Type;
    }

    public void setBenificiary_Type(String benificiary_Type) {
        Benificiary_Type = benificiary_Type;
    }

    public Detail(String name_Initial, String name_Denoted, String birthday, String NIC, String gender, String family_Members, String address, String job, String tele_Number, String income, String ds_Zone, String GN_Zone, String name_Ssociety, String benificiary_Type) {
        Name_Initial = name_Initial;
        Name_Denoted = name_Denoted;
        Birthday = birthday;
        this.NIC = NIC;
        Gender = gender;
        Family_Members = family_Members;
        Address = address;
        Job = job;
        Tele_Number = tele_Number;
        Income = income;
        Ds_Zone = ds_Zone;
        this.GN_Zone = GN_Zone;
        Name_Ssociety = name_Ssociety;
        Benificiary_Type = benificiary_Type;
    }
}
