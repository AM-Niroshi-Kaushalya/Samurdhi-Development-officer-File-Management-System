package com.project1.project1;
import Models.BenificiaryModel;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ResourceBundle;


public class DetailController implements Initializable {
    @FXML
    private TableColumn<Detail, String> Address;

    @FXML
    private TableColumn<Detail, String> Benificiary_Type;

    @FXML
    private TableColumn<Detail, String> Birthday;

    @FXML
    private TableColumn<Detail, String> Ds_Zone;

    @FXML
    private TableColumn<Detail, String> Family_Members;

    @FXML
    private TableColumn<Detail, String> GN_Zone;

    @FXML
    private TableColumn<Detail, String> Gender;

    @FXML
    private TableColumn<Detail, String> Income;

    @FXML
    private TableColumn<Detail, String> Job;

    @FXML
    private TableColumn<Detail, String> NIC;

    @FXML
    private TableColumn<Detail, String> Name_Denoted;

    @FXML
    private TableColumn<Detail, String> Name_Initial;

    @FXML
    private TableColumn<Detail, String> Name_Ssociety;

    @FXML
    private TableView<Detail> TableDetail;

    @FXML
    private TableColumn<Detail, String> Tel_Number;
    @FXML
    private Button Btndelete;



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        BenificiaryModel benificiaryModel = new BenificiaryModel();
        Name_Initial.setCellValueFactory(new PropertyValueFactory<Detail, String>("Name_Initial"));
        Name_Denoted.setCellValueFactory(new PropertyValueFactory<Detail, String>("Name_Denoted"));
        Birthday.setCellValueFactory(new PropertyValueFactory<Detail, String>("Birthday"));
        NIC.setCellValueFactory(new PropertyValueFactory<Detail, String>("NIC"));
        Gender.setCellValueFactory(new PropertyValueFactory<Detail, String>("Gender"));
        Family_Members.setCellValueFactory(new PropertyValueFactory<Detail, String>("Family_Members"));
        Address.setCellValueFactory(new PropertyValueFactory<Detail, String>("Address"));
        Job.setCellValueFactory(new PropertyValueFactory<Detail, String>("Job"));
        Tel_Number.setCellValueFactory(new PropertyValueFactory<Detail, String>("Tele_Number"));
        Income.setCellValueFactory(new PropertyValueFactory<Detail, String>("Income"));
        Ds_Zone.setCellValueFactory(new PropertyValueFactory<Detail, String>("Ds_Zone"));
        GN_Zone.setCellValueFactory(new PropertyValueFactory<Detail, String>("GN_Zone"));
        Name_Ssociety.setCellValueFactory(new PropertyValueFactory<Detail, String>("Name_Ssociety"));
        Benificiary_Type.setCellValueFactory(new PropertyValueFactory<Detail, String>("Benificiary_Type"));
        TableDetail.setItems(BenificiaryModel.getUser());
    }
    @FXML
    void btndelete(ActionEvent event) {
        String NIC=TableDetail.getSelectionModel().getSelectedItem().NIC;
        BenificiaryModel benificiaryModel= new BenificiaryModel();
        boolean result = benificiaryModel.delBenificiary(NIC);
        TableDetail.setItems(null);
        TableDetail.setItems(BenificiaryModel.getUser());
        System.out.println(result);

    }

    }








