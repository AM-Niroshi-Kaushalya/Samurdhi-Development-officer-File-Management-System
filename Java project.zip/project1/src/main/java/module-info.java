module com.project1.project1 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires bcrypt;





    opens com.project1.project1 to javafx.fxml;
    exports com.project1.project1;
    exports com.project1.project1.controller;
    opens com.project1.project1.controller to javafx.fxml;
}