package Models;

import com.project1.project1.Detail;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BenificiaryModel {
    private Connection conn = Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;
    public static ObservableList<Detail> getUser(){
        Connection Conn = Db.getConn();
        ObservableList<Detail>list= FXCollections.observableArrayList();
        String sql="SELECT * FROM details";
        try {
            PreparedStatement stmt;
            stmt = Conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                String Name_Initial=rs.getString("Name_Initial");
                String Name_Denoted=rs.getString("Name_Denoted");
                String Birthday=rs.getString("Birthday");
                String NIC=rs.getString("NIC");
                String Gender=rs.getString("Gender");
                String Family_Members=rs.getString("Family_Members");
                String Address=rs.getString("Address");
                String Job=rs.getString("Job");
                String Tele_Number=rs.getString("Tele_Number");
                String Income=rs.getString("Income");
                String Ds_Zone=rs.getString("Ds_Zone");
                String GN_Zone=rs.getString("GN_Zone");
                String Name_Ssociety=rs.getString("Name_Ssociety");
                String Benificiary_Type=rs.getString("Benificiary_Type");

                list.add(new Detail(Name_Initial, Name_Denoted, Birthday, NIC, Gender, Family_Members, Address,Job, Tele_Number, Income, Ds_Zone, GN_Zone, Name_Ssociety, Benificiary_Type));
            }
        }
        catch (SQLException e){
            System.out.println((e.getMessage()));
        }
        return list;
    }
    public boolean delBenificiary(String NIC){
        boolean result = false;
        String sql = "DELETE FROM `details` WHERE NIC = ? LIMIT 1";
        try {
            stmt= conn.prepareStatement(sql);
            stmt.setString(1,NIC);
            result= stmt.executeUpdate()==1;

        }
        catch (SQLException e){
            throw  new RuntimeException(e);
        }
        return result;

    }
}
