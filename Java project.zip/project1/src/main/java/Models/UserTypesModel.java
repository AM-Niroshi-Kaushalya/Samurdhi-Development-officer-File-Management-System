package Models;


//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;

public class UserTypesModel {
//    public static Connection Conn = Db.getConn();
//    //private preparedstatement statement
//    private static ResultSet rs;
//    public  ResultSet getTypes(){
//        String sql = "SELECT * FROM user_type";
//
//        try {
//            PreparedStatement statement = Conn.prepareStatement(sql);
//            rs = statement.executeQuery();
//        } catch (SQLException e) {
//            throw new RuntimeException(e);
//        }
//        return rs;
//
//    }}
}