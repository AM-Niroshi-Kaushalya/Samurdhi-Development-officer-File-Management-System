package Models;

import java.sql.Connection;
import java.sql.SQLException;

import java.sql.DriverManager;

public class Db{
    public static Connection Dbconn;
    public static Connection getConn;

    public static Connection getConn(){
        try{
            Dbconn= DriverManager.getConnection("jdbc:mysql://localhost/samurdhi","root","");
        }catch (SQLException exx){
            System.out.println(exx.getMessage());
        }
        return Dbconn;
        }


        }


