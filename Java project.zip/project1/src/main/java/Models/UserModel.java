package Models;

//import at.favre.lib.crypto.bcrypt.BCrypt;

import at.favre.lib.crypto.bcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserModel {
    private static Connection connection=Db.getConn();
    private PreparedStatement stmt;
    private ResultSet rs;

    public  static  boolean btnloggin(String username,String password){
        boolean result =false;
        String sql="INSERT INTO user(User_name,Password)VALUES(?,?)";
        try{
            PreparedStatement stat ;
            stat=connection.prepareStatement(sql);
            stat.setString(1,username);
            stat.setString(2,password);
            result=stat.executeUpdate()==1;

        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return result;
    }
    public boolean login(String username,String password){
        boolean result=false;
        String sql="SELECT User_name,Password FROM user WHERE User_name=? LIMIT 1";
        try {
            stmt=connection.prepareStatement(sql);
            stmt.setString(1,username);
            ResultSet rs= stmt.executeQuery();
            if(rs.next()){
                BCrypt.Result checkpwd=BCrypt.verifyer().verify(password.toCharArray(),rs.getString("password"));
                result=checkpwd.verified;
            }
        }
        catch (SQLException e){
            System.out.println(e.getMessage());
        }
        return result;

}}

