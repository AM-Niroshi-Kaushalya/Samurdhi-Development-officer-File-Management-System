package Models;
import com.project1.project1.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class TestModel {
//    private  Connection connection=Db.getConn();
//    private  PreparedStatement stmt ;
//    private ResultSet rs;
//    public static ObservableList<Student> getUser() {
//        Connection Conn = Db.getConn();
//        ObservableList<Student> list = FXCollections.observableArrayList();
//        String sql = "SELECT * FROM student";
//        try {
//            PreparedStatement stmt;
//            stmt = Conn.prepareStatement(sql);
//            ResultSet rs = stmt.executeQuery();
//            while (rs.next()) {
//                String id = rs.getString("id");
//                String name = rs.getString("name");
//                list.add(new Student(id, name));
//            }
//        } catch (SQLException e) {
//            System.out.println((e.getMessage()));
//        }
//        return list;
//    }
}
