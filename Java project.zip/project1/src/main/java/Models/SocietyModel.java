package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SocietyModel {
    public static Connection Conn = Db.getConn();
    //private preparedstatement statement
    private static ResultSet rss;
    public  ResultSet getTypes(){
        String sql ="SELECT * FROM `ssociety`";

        try {
            PreparedStatement statement = Conn.prepareStatement(sql);
            rss = statement.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return rss;

    }}

