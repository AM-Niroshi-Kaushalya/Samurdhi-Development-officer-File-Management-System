package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DetailModel {
    private static Connection connection = Db.getConn();
    private PreparedStatement stat;
    private ResultSet rs;
    public static boolean Detail(String Iname, String Dname, String DBirth, String Nic, String Gender, String Family, String Address, String Job, String Telenu, String Mincome, String DevitionalZ, String st2, String st3, String st4) {
        boolean result = false;
        String sql = "INSERT INTO details(Name_Initial, Name_Denoted, Birthday, NIC, Gender, Family_Members, Address, Job, Tele_Number, Income, Ds_Zone, GN_Zone, Name_Ssociety, Benificiary_Type) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement stat;
            stat = connection.prepareStatement(sql);

            stat.setString(1, Iname);
            stat.setString(2, Dname);
            stat.setString(3, DBirth);
            stat.setString(4, Nic);
            stat.setString(5, Gender);
            stat.setString(6, Family);
            stat.setString(7, Address);
            stat.setString(8, Job);
            stat.setString(9, Telenu);
            stat.setString(10, Mincome);
            stat.setString(11, DevitionalZ);
            stat.setString(12, st2);
            stat.setString(13, st3);
            stat.setString(14, st4);
            result = stat.executeUpdate() == 1;
        } catch (SQLException se) {
            System.out.println(se.getMessage());
        }
        return result;
}}
