package Models;


import com.project1.project1.Detail;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateModel {
   public static ObservableList<Detail> getUpdate;
   private Connection conn = Db.getConn();
   private PreparedStatement stmt;
   private ResultSet rs;

   public  ObservableList<Detail> getUpdate(){
      Connection Conn = Db.getConn();
      ObservableList<Detail>list= FXCollections.observableArrayList();
      String sql="SELECT * FROM details";
      try {
         PreparedStatement stmt;
         stmt = Conn.prepareStatement(sql);
         ResultSet rs = stmt.executeQuery();
         while (rs.next()){
            String Name_Initial=rs.getString("Name_Initial");
            String Name_Denoted=rs.getString("Name_Denoted");
            String Birthday=rs.getString("Birthday");
            String NIC=rs.getString("NIC");
            String Gender=rs.getString("Gender");
            String Family_Members=rs.getString("Family_Members");
            String Address=rs.getString("Address");
            String Job=rs.getString("Job");
            String Tele_Number=rs.getString("Tele_Number");
            String Income=rs.getString("Income");
            String Ds_Zone=rs.getString("Ds_Zone");
            String GN_Zone=rs.getString("GN_Zone");
            String Name_Ssociety=rs.getString("Name_Ssociety");
            String Benificiary_Type=rs.getString("Benificiary_Type");

            list.add(new Detail(Name_Initial, Name_Denoted, Birthday, NIC, Gender, Family_Members, Address,Job, Tele_Number, Income, Ds_Zone, GN_Zone, Name_Ssociety, Benificiary_Type));
         }
      }
      catch (SQLException e){
         System.out.println((e.getMessage()));
      }
      return list;
   }
   public boolean Updateuser(String name_Initial, String name_Denoted, String birthday, String NIC, String gender, String family_Members, String address, String job, String tele_Number, String income, String ds_Zone, String GN_Zone, String name_Ssociety, String benificiary_Type)

   {
      boolean result = false;
      PreparedStatement stmt;
      Connection con = Db.getConn();
      String sql = "update details set Name_Initial= '"+name_Initial+"', Name_Denoted= '"+name_Denoted+"',Birthday= '"+birthday+"',NIC= '"+NIC+"',Gender= '"+gender+"',Family_Members= '"+family_Members+"',Address= '"+address+"',Job= '"+job+"',Tele_Number= '"+tele_Number+"',Income= '"+income+"',Ds_Zone= '"+ds_Zone+"',GN_Zone= '"+GN_Zone+"',Name_Ssociety= '"+name_Ssociety+"',Name_Ssociety= '"+benificiary_Type+"' where NIC= '"+NIC+"'";

      //UPDATE `details` SET `Name_Initial`=[value-1],`Name_Denoted`=[value-2],`Birthday`=[value-3],`NIC`=[value-4],`Gender`=[value-5],`Family_Members`=[value-6],`Address`=[value-7],`Job`=[value-8],`Tele_Number`=[value-9],`Income`=[value-10],`Ds_Zone`=[value-11],`GN_Zone`=[value-12],`Name_Ssociety`=[value-13],`Benificiary_Type`=[value-14] WHERE 1
      try {

         stmt = con.prepareStatement(sql);


         result = stmt.executeUpdate() == 1;

      } catch (SQLException e) {
         throw new RuntimeException(e);


      }
      return result;


   }
   public ResultSet getType1() {
      Connection con = Db.getConn();
      PreparedStatement stmt;
      ResultSet rs;

      String sql = "SELECT NIC FROM `details` ";
      try {
         stmt = con.prepareStatement(sql);
         rs = stmt.executeQuery();


      } catch (SQLException e) {
         throw new RuntimeException(e);
      }
      return rs;

   }





}

